def empty_file(file_path):
   
    try:
        # Open the file in write mode to clear its contents
        with open(file_path, 'w') as file:
            pass  # Writing nothing clears the file
        # print(f"File '{file_path}' has been emptied successfully.")
        return True
    except Exception as e:
        # print(f"An error occurred while emptying the file: {e}")
        return False

# Example Usage
file_path = "ocr.txt"  # Replace with the path to your text file
empty_file(file_path)
