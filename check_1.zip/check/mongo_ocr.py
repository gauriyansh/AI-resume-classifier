from pymongo import MongoClient
from bson import SON ,Binary, ObjectId
import gridfs
from PIL import Image
from io import BytesIO
import pytesseract

def mongo_ocr():
# MongoDB Setup
    client = MongoClient("mongodb://localhost:27017")  # Replace with your MongoDB connection string
    db = client['DEST']  # Replace with your database name

    # Create a GridFS object
    fs = gridfs.GridFS(db)

    # Path to your image file on macOS
    image_path = "C://Users//MADDY//Desktop//18-19 hackathon//check//uploads//resume.png"  # Replace with your image path

    # Open the image file in binary mode and store it in GridFS
    with open(image_path, 'rb') as f:
        image_data = f.read()
    image_id = fs.put(image_data, filename="your_image_name.jpg")

    # Print confirmation of storage
    # print(f"Image stored with ID: {image_id}")

    # Retrieve the image by ID
    stored_image = fs.get(image_id)

    # Read the image data
    retrieved_image_data = stored_image.read()

    # Perform OCR on the retrieved image data

    try:
        # Set Tesseract command path
        pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
        
        # Convert the binary data back to an image using BytesIO
        image = Image.open(BytesIO(retrieved_image_data))
        
        # Perform OCR
        text = pytesseract.image_to_string(image)
        
        # Write the extracted text to a file
        with open("ocr.txt", "w", encoding="utf-8") as file:
            # file.write("Extracted Text from Image:\n")
            file.write(text)
        
        # print("OCR data successfully written to ocr.txt")

    except Exception as e:
        print(f"An error occurred during OCR: {e}")

    # Close the MongoDB connection
    client.close()

mongo_ocr()
