const fileUploadArea1 = document.getElementById('fileUploadArea1');
const fileInput1 = document.getElementById('fileInput1');
const uploadBtn1 = document.getElementById('uploadBtn1');

const fileUploadArea2 = document.getElementById('fileUploadArea2');
const fileInput2 = document.getElementById('fileInput2');
const uploadBtn2 = document.getElementById('uploadBtn2');

const compareBtn = document.getElementById('compareBtn');

// Drag and Drop functionality for the first CV
fileUploadArea1.addEventListener('dragover', (e) => {
    e.preventDefault();
    fileUploadArea1.classList.add('drag-over');
});

fileUploadArea1.addEventListener('dragleave', () => {
    fileUploadArea1.classList.remove('drag-over');
});

fileUploadArea1.addEventListener('drop', (e) => {
    e.preventDefault();
    fileUploadArea1.classList.remove('drag-over');
    const files = e.dataTransfer.files;
    if (files.length) {
        console.log('First CV dropped:', files[0]);
    }
});

// Choose File for the first CV
uploadBtn1.addEventListener('click', () => {
    fileInput1.click();
});

fileInput1.addEventListener('change', (e) => {
    console.log('First CV selected:', e.target.files[0]);
});

// Drag and Drop functionality for the second CV
fileUploadArea2.addEventListener('dragover', (e) => {
    e.preventDefault();
    fileUploadArea2.classList.add('drag-over');
});

fileUploadArea2.addEventListener('dragleave', () => {
    fileUploadArea2.classList.remove('drag-over');
});

fileUploadArea2.addEventListener('drop', (e) => {
    e.preventDefault();
    fileUploadArea2.classList.remove('drag-over');
    const files = e.dataTransfer.files;
    if (files.length) {
        console.log('Second CV dropped:', files[0]);
    }
});

// Choose File for the second CV
uploadBtn2.addEventListener('click', () => {
    fileInput2.click();
});

fileInput2.addEventListener('change', (e) => {
    console.log('Second CV selected:', e.target.files[0]);
});

// Compare functionality
compareBtn.addEventListener('click', () => {
    const firstCV = fileInput1.files[0];
    const secondCV = fileInput2.files[0];
    if (firstCV && secondCV) {
        console.log('Comparing:', firstCV.name, 'and', secondCV.name);
        alert(`Comparing ${firstCV.name} and ${secondCV.name}`);
    } else {
        alert('Please upload both CVs to compare.');
    }
});
