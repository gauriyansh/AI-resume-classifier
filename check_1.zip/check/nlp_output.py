import importlib.util
import pandas as pd
import nlp_data_2

# Load the module from the given file path

def nlp_output():
    model_path = r"C:\Users\MADDY\Desktop\18-19 hackathon\backend\nlp_data_2.py"
    spec = importlib.util.spec_from_file_location("nlp_data_2", model_path)
    nlp_data_2 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(nlp_data_2)

    # Import the ResumeProcessor class from the loaded module
    ResumeProcessor = nlp_data_2.ResumeProcessor

    # Update the file path to the correct location on your local machine
    excel_path = "C:\\Users\\MADDY\\Desktop\\18-19 hackathon\\check\\Software_Engineers_Resume_Data.xlsx"

    # Load the Excel file
    try:
        data = pd.read_excel(excel_path)
    except FileNotFoundError:
        print(f"Error: File not found at {excel_path}")
        exit()

    # Extract keywords from the spreadsheet
    skills_keywords = set(', '.join(data['Skills'].dropna()).split(', ')) if 'Skills' in data.columns else set()

    # Initialize the ResumeProcessor
    processor = ResumeProcessor(skills_keywords=skills_keywords)

    # Example resume text for testing
    # Specify the file name
    file_name = "ocr.txt"

    try:
        # Open the file in read mode
        with open(file_name, "r", encoding="utf-8") as file:
            # Read the contents of the file
            resume_example = file.read()
        
            
    except FileNotFoundError:
        print(f"The file '{file_name}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")


    # Process the example resume
    processed_data = processor.process_resume(resume_example)

    # Display the results
    # print(processed_data)

    