from y_n import response
from calender_con import g_connect

# Check the response and trigger event creation
if response == "Yes":
    print("Response is 'Yes'. Adding event to Google Calendar...")
    g_connect()  # Call the function to add the event
    print("Event has been added successfully!")
else:
    print("Response is 'No'. No action taken.")
