# import re
# import spacy

# class ResumeProcessor:
#     def __init__(self, skills_keywords=None, education_keywords=None):
#         # Load SpaCy model
#         try:
#             self.nlp = spacy.load("en_core_web_sm")
#         except OSError:
#             print("SpaCy model 'en_core_web_sm' not found. Installing...")
#             import subprocess
#             subprocess.run(["python", "-m", "spacy", "download", "en_core_web_sm"], check=True)
#             self.nlp = spacy.load("en_core_web_sm")

#         # Initialize keywords
#         self.skills_keywords = skills_keywords if skills_keywords else set()
#         self.education_keywords = education_keywords if education_keywords else {"M.Tech", "B.Tech", "M.Sc", "B.Sc", "PhD", "MBA", "BCA", "MCA", "B.E", "M.E"}

#     def extract_experience(self, text):
#         match = re.search(r'(\d+)\s+years?', text, re.IGNORECASE)
#         return int(match.group(1)) if match else None

#     def extract_skills(self, text):
#         doc = self.nlp(text)
#         skills = [token.text for token in doc if token.text in self.skills_keywords]
#         return list(set(skills))

#     def extract_education(self, text):
#         education = [keyword for keyword in self.education_keywords if keyword.lower() in text.lower()]
#         education = list(set(education))


#         # Prioritize higher education over lower ones
#         if "M.Tech" in education or "M.Sc" in education:
#             education = [qual for qual in education if qual not in {"B.Tech", "B.Sc"}]
#         if "PhD" in education:
#             education = [qual for qual in education if qual != "M.Tech" and qual != "M.Sc"]
#         if "MBA" in education:
#             education = [qual for qual in education if qual not in {"B.Tech", "B.Sc"}]

#         return education

#     def process_resume(self, resume_text):
#         experience = self.extract_experience(resume_text)
#         skills = self.extract_skills(resume_text)
#         education = self.extract_education(resume_text)

#         return {
#             'Experience (years)': experience,
#             'Skills': skills,
#             'Education': education
#         }
        
        
import re

class ResumeProcessor:
    def __init__(self, skills_keywords=None, education_keywords=None):
        # Initialize keywords
        self.skills_keywords = skills_keywords if skills_keywords else set()
        self.education_keywords = education_keywords if education_keywords else {
            "M.Tech", "B.Tech", "M.Sc", "B.Sc", "PhD", "MBA", "BCA", "MCA", "B.E", "M.E"
        }

    def extract_experience(self, text):
        """
        Extract the years of experience mentioned in the resume text.
        """
        match = re.search(r'(\d+)\s+years?', text, re.IGNORECASE)
        return int(match.group(1)) if match else None

    def extract_skills(self, text):
        """
        Extract skills based on the provided keywords.
        """
        # Tokenize the text into words
        tokens = re.findall(r'\b\w+\b', text.lower())
        skills = [word for word in tokens if word in {skill.lower() for skill in self.skills_keywords}]
        return list(set(skills))

    def extract_education(self, text):
        """
        Extract education qualifications from the text.
        """
        text_lower = text.lower()
        education = [keyword for keyword in self.education_keywords if keyword.lower() in text_lower]
        education = list(set(education))

        # Prioritize higher education over lower ones
        if "M.Tech" in education or "M.Sc" in education:
            education = [qual for qual in education if qual not in {"B.Tech", "B.Sc"}]
        if "PhD" in education:
            education = [qual for qual in education if qual != "M.Tech" and qual != "M.Sc"]
        if "MBA" in education:
            education = [qual for qual in education if qual not in {"B.Tech", "B.Sc"}]

        return education

    def process_resume(self, resume_text):
        """
        Process the resume text and extract experience, skills, and education.
        """
        experience = self.extract_experience(resume_text)
        skills = self.extract_skills(resume_text)
        education = self.extract_education(resume_text)

        return {
            'Experience (years)': experience,
            'Skills': skills,
            'Education': education
        }
