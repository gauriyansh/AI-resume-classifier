import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from imblearn.under_sampling import RandomUnderSampler
from sklearn.pipeline import Pipeline

# Load the dataset
file_path = "C:\\Users\\MADDY\\Desktop\\18-19 hackathon\\check\\Software_Engineers_Resume_Data.xlsx"
data = pd.read_excel(file_path, sheet_name=0)

# Preprocessing: Extract years of experience
# Convert "Experience" column to numeric (e.g., "5 years" -> 5)
data['Experience_Years'] = data['Experience'].str.extract('(\d+)').fillna(0).astype(int)

# Encode target variable (Suitable -> 1, Not Suitable -> 0)
data['Classified_Label'] = np.where(data['Classified'] == 'Suitable', 1, 0)

# Combine textual features for TF-IDF
data['Text_Features'] = data['Skills'] + ' ' + data['Summary']
data['Text_Features'] = data['Text_Features'].fillna('')

# Handle class imbalance using undersampling
X = data[['Text_Features', 'Experience_Years']]
y = data['Classified_Label']

undersampler = RandomUnderSampler(random_state=42)
X_balanced, y_balanced = undersampler.fit_resample(X, y)

# Split the balanced dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X_balanced, y_balanced, test_size=0.2, random_state=42
)

# Define a pipeline with TF-IDF vectorizer and Random Forest classifier
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(max_features=5000, stop_words='english')),
    ('rf', RandomForestClassifier(n_estimators=200, random_state=42))
])

# Train the model
pipeline.fit(X_train['Text_Features'], y_train)

# Make predictions
predictions = pipeline.predict(X_test['Text_Features'])

# Evaluate the model
print("Confusion Matrix:")
print(confusion_matrix(y_test, predictions))
print("\nClassification Report:")
print(classification_report(y_test, predictions))

# Save the model for future use
import joblib
model_path = 'resume_rf_model.pkl'
joblib.dump(pipeline, model_path)
print(f"Model saved to {model_path}")
