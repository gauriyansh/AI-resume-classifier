const express = require('express');
const { spawn } = require('child_process');
const path = require('path');
const app = express();
const port = 3000;

// Serve static files (including index.html, CSS, and JS)
app.use(express.static(path.join(__dirname)));

// Endpoint to run Python script and get the coin flip result
app.get('/flip-coin', (req, res) => {
    const pythonProcess = spawn('python', ['y_n.py']);

    pythonProcess.stdout.on('data', (data) => {
        const result = data.toString().trim();  // Get the result from Python
        res.json({ result });  // Send the result back to the client
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Error: ${data}`);
        res.status(500).json({ error: 'Error running Python script' });
    });

    pythonProcess.on('close', (code) => {
        if (code !== 0) {
            console.log(`Python script exited with code ${code}`);
        }
    });
});

// Default route to serve the home.html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html')); // Corrected the path
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
