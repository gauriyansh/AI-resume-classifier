document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.accordion-title').forEach((title) => {
        title.addEventListener('click', () => {
            const item = title.parentElement;
            const content = item.querySelector('.accordion-content');
            const isActive = item.classList.contains('active');

            // Remove active class from all accordion items
            document.querySelectorAll('.accordion-item').forEach((otherItem) => {
                otherItem.classList.remove('active');
                otherItem.querySelector('.accordion-content').style.display = 'none'; // Hide content
            });

            // If the item wasn't active, make it active and show its content
            if (!isActive) {
                item.classList.add('active');
                content.style.display = 'block'; // Show content
            }
        });
    });
});
