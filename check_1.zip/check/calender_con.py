from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import os
import datetime

def authenticate_google_calendar(credentials_file="yo_yo2.json"):
    """
    Authenticate with Google Calendar API using the provided credentials file.
    """
    SCOPES = ['https://www.googleapis.com/auth/calendar']
    creds = None

    # Check if token.pickle exists
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If no valid credentials, authenticate
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                credentials_file, SCOPES
            )
            creds = flow.run_local_server(port=8080)  # Use local port for redirect

        # Save the credentials for future use
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    # Return the authenticated service
    return build('calendar', 'v3', credentials=creds)

def g_connect():
    """
    Add a default task to Google Calendar.
    """
    service = authenticate_google_calendar("yo_yo2.json")

    # Task details
    task_name = "check Task"
    task_time = '2025-01-18 11:00'

    # Parse task time
    task_datetime = datetime.datetime.strptime(task_time, "%Y-%m-%d %H:%M")
    start_time = task_datetime.isoformat()
    end_time = (task_datetime + datetime.timedelta(hours=1)).isoformat()  # Default 1-hour event

    # Create event object
    event = {
        'summary': task_name,
        'start': {'dateTime': start_time, 'timeZone': 'Asia/Kolkata'},
        'end': {'dateTime': end_time, 'timeZone': 'Asia/Kolkata'},
    }

    # Add event to calendar
    event_result = service.events().insert(calendarId='primary', body=event).execute()

    # Output event details
    print(f"Task '{task_name}' added to Google Calendar.")
    print(f"Event Link: {event_result.get('htmlLink')}")  # Provide event link
