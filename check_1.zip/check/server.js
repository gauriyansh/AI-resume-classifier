const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const app = express();
const port = 3000;

// Serve static files (e.g., index.html, CSS, JS)
app.use(express.static(path.join(__dirname)));

// Configure multer for file uploads
const upload = multer({
    dest: path.join(__dirname, 'uploads'), // Temporary folder to store uploads
});

// Upload endpoint
app.post('/upload', upload.single('file'), (req, res) => {
    const file = req.file;

    if (!file) {
        return res.status(400).json({ message: 'No file uploaded.' });
    }

    // Determine the file extension
    const fileExtension = path.extname(file.originalname); // Extract the file extension
    const targetPath = path.join(__dirname, 'uploads', `resume${fileExtension}`); // Save as 'resume.<extension>'

    // Rename the temporary file to the target path
    fs.rename(file.path, targetPath, (err) => {
        if (err) {
            console.error('Error saving file:', err);
            return res.status(500).json({ message: 'Error saving file.' });
        }

        console.log(`File saved to: ${targetPath}`);
        res.json({ message: 'File uploaded successfully.', filePath: targetPath });
    });
});

// Endpoint to run the Python script
app.get('/flip-coin', (req, res) => {
    const pythonProcess = spawn('python', ['y_n.py']); // Run the Python script

    let output = '';

    pythonProcess.stdout.on('data', (data) => {
        output += data.toString(); // Collect Python script's output
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Error running Python script: ${data}`);
        res.status(500).json({ error: 'Error running Python script' });
    });

    pythonProcess.on('close', (code) => {
        if (code === 0) {
            res.json({ result: output.trim() }); // Send the Python script's output to the client
        } else {
            console.log(`Python script exited with code ${code}`);
            res.status(500).json({ error: `Python script exited with code ${code}` });
        }
    });
});

// Default route to serve the home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'home.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
