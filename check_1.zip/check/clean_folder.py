import os
import shutil

def empty_folder(folder_path):
    """
    Deletes all files and subfolders in the specified folder.
    :param folder_path: Path to the folder to empty.
    """
    try:
        # Check if the folder exists
        if not os.path.exists(folder_path):
            print(f"The folder '{folder_path}' does not exist.")
            return

        # Iterate through all files and subfolders in the folder
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            
            # Check if it's a file or folder and delete accordingly
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # Delete file or symbolic link
                # print(f"Deleted file: {file_path}")
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)  # Delete folder
                # print(f"Deleted folder: {file_path}")

        # print(f"The folder '{folder_path}' has been emptied successfully.")
    except Exception as e:
        print(f"An error occurred while emptying the folder: {e}")

