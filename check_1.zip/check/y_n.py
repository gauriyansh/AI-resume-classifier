import random
from mongo_ocr import mongo_ocr
from nlp_output import nlp_output
from clean_folder import empty_folder
from R_to_py import R_to_py
from empty_ocr import empty_file


def main():
    # Step 1: Perform OCR on the uploaded image and store data in MongoDB
   
    mongo_ocr()

    
    # Step 2: Process the extracted text with NLP

    answer = R_to_py()
    
    file_path = 'ocr.txt'
    empty_file(file_path)
    # Step 3: Clean the uploads folder
    uploads_folder = "C://Users//MADDY//Desktop//18-19 hackathon//check//uploads"
    
    empty_folder(uploads_folder)
   

    # Step 4: Generate a random response ("Yes" or "No")
    answers = answer
    print(f'The following Candidate is {answers}')  # Output the result for the server to capture

    # Step 5: Trigger event creation if the response is "Yes"
    if answers == "Suitable":
        # You can uncomment the g_connect function call once it's properly implemented
        # g_connect()  # Add an event to Google Calendar
        print("Event has been added successfully!")
    else:
        print("No action taken.")


if __name__ == "__main__":
    main()
