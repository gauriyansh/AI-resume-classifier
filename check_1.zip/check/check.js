// DOM Elements
const fileUploadArea = document.getElementById('fileUploadArea');
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');
const cancelBtn = document.getElementById('cancelBtn');
const responseArea = document.getElementById('responseArea');
const responseText = document.getElementById('response');
const showButton = document.getElementById('showButton'); // Show button for fetching the coin flip result

// Drag and Drop functionality
fileUploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    fileUploadArea.classList.add('drag-over');
});

fileUploadArea.addEventListener('dragleave', () => {
    fileUploadArea.classList.remove('drag-over');
});

fileUploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    fileUploadArea.classList.remove('drag-over');
    const files = e.dataTransfer.files;
    if (files.length) {
        console.log('File dropped:', files[0]);
        uploadFile(files[0]);
    }
});

// Choose File Button
uploadBtn.addEventListener('click', () => {
    fileInput.click();
});

// Handle file selection
fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) {
        const file = e.target.files[0];
        console.log('File selected:', file);
        uploadFile(file);
    }
});

// Cancel Button
cancelBtn.addEventListener('click', () => {
    fileInput.value = ''; // Clear the file input
    console.log('File selection cancelled');
    responseText.textContent = ''; // Clear response text
    responseArea.style.display = 'none'; // Hide response area
});

// Upload file to the server
function uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);

    fetch('/upload', {
        method: 'POST',
        body: formData,
    })
        .then((response) => response.json())
        .then((data) => {
            console.log('Upload successful:', data);
            responseText.textContent = `File uploaded successfully: ${data.filePath}`;
            responseArea.style.display = 'block';
        })
        .catch((error) => {
            console.error('Error uploading file:', error);
            responseText.textContent = 'Error uploading file.';
            responseArea.style.display = 'block';
        });
}

// Show Button functionality to fetch the coin flip result
showButton.addEventListener('click', async () => {
    try {
        const response = await fetch('/flip-coin');
        const data = await response.json();
        responseText.textContent = `Coin Flip Result: ${data.result}`; // Display "Yes" or "No"
        responseArea.style.display = 'block';
    } catch (error) {
        console.error('Error fetching response:', error);
        responseText.textContent = 'Error fetching the coin flip result.';
        responseArea.style.display = 'block';
    }
});
