import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'  # Suppresses INFO and WARNING logs, showing only ERROR logs.

import importlib.util
import joblib
import pandas as pd

# Load the NLP processing module
nlp_module_path = r"C:\Users\MADDY\Desktop\18-19 hackathon\check\nlp_data_2.py"
spec = importlib.util.spec_from_file_location("nlp_data_2", nlp_module_path)
nlp_data_2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(nlp_data_2)

# Import the ResumeProcessor class
ResumeProcessor = nlp_data_2.ResumeProcessor

# Load the trained model
model_path = r"C:\Users\MADDY\Desktop\18-19 hackathon\check\resume_rf_model.pkl"
model = joblib.load(model_path)

# Initialize ResumeProcessor with skills from the dataset
excel_path = "C:\\Users\\MADDY\\Desktop\\18-19 hackathon\\check\\Software_Engineers_Resume_Data.xlsx"
try:
    data = pd.read_excel(excel_path)
except FileNotFoundError:
    print(f"Error: File not found at {excel_path}")
    exit()

# Extract keywords from the spreadsheet
skills_keywords = set(', '.join(data['Skills'].dropna()).split(', ')) if 'Skills' in data.columns else set()

# Initialize ResumeProcessor
processor = ResumeProcessor(skills_keywords=skills_keywords)

# Function to evaluate a resume
def evaluate_resume(resume_text):
    # Step 1: Process the resume using the ResumeProcessor
    processed_data = processor.process_resume(resume_text)

    # Step 2: Prepare features for the model
    # Combine skills and education into a single text feature
    text_features = " ".join(processed_data['Skills']) + " " + " ".join(processed_data['Education'])

    # Create a DataFrame with features
    input_df = pd.DataFrame({
        "Text_Features": [text_features],
        "Experience_Years": [processed_data['Experience (years)'] or 0]  # Use 0 if experience is None
    })

    # Step 3: Predict using the trained model
    prediction = model.predict(input_df[['Text_Features', 'Experience_Years']])
    prediction_label = "Suitable" if prediction[0] == 1 else "Not Suitable"

    # Step 4: Display the results
    return prediction_label

# Example: Automate the evaluation process
def R_to_py():
    file_name = "ocr.txt"

    try:
        # Open the file in read mode
        with open(file_name, "r", encoding="utf-8") as file:
            # Read the contents of the file
            resume_example = file.read()
        
            
    except FileNotFoundError:
        print(f"The file '{file_name}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")
    
    # Evaluate the given resume
    return evaluate_resume(resume_example)



k = R_to_py()
print(k)
